#!/usr/bin/env bash
set -euo pipefail

# PERDI PROXY SERVER - authenticated Squid HTTP/HTTPS CONNECT proxy
# Tested design target: Ubuntu Server 22.04 / 24.04.
# Restrict access to one client public IP; do not run this as an open proxy.

if [[ "${EUID}" -ne 0 ]]; then
  echo "Jalankan sebagai root: sudo bash install-perdi-proxy.sh"
  exit 1
fi

if ! grep -qi ubuntu /etc/os-release; then
  echo "Script ini ditujukan untuk Ubuntu Server."
  exit 1
fi

echo "=== PERDI PROXY SERVER INSTALLER ==="
echo "Proxy ini memakai autentikasi dan firewall allowlist IP."
read -r -p "Masukkan IP publik perangkat yang akan memakai proxy: " CLIENT_IP
if [[ ! "$CLIENT_IP" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
  echo "Format IPv4 tidak valid."
  exit 1
fi
# Validate each IPv4 octet.
IFS='.' read -r o1 o2 o3 o4 <<< "$CLIENT_IP"
for octet in "$o1" "$o2" "$o3" "$o4"; do
  if (( octet < 0 || octet > 255 )); then
    echo "IP IPv4 tidak valid."
    exit 1
  fi
done

read -r -p "Username proxy (contoh: perdi): " PROXY_USER
if [[ ! "$PROXY_USER" =~ ^[a-zA-Z0-9._-]{3,32}$ ]]; then
  echo "Username harus 3-32 karakter: huruf, angka, titik, _ atau -."
  exit 1
fi
read -r -s -p "Password proxy (minimal 16 karakter): " PROXY_PASS
echo
if (( ${#PROXY_PASS} < 16 )); then
  echo "Gunakan password minimal 16 karakter."
  exit 1
fi
read -r -s -p "Ulangi password: " PROXY_PASS2
echo
if [[ "$PROXY_PASS" != "$PROXY_PASS2" ]]; then
  echo "Password tidak cocok."
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y squid apache2-utils ufw

# Keep a backup of the existing Squid configuration.
if [[ -f /etc/squid/squid.conf ]]; then
  cp /etc/squid/squid.conf "/etc/squid/squid.conf.perdi-backup.$(date +%Y%m%d%H%M%S)"
fi

install -d -o proxy -g proxy -m 0750 /etc/squid
htpasswd -bc /etc/squid/passwd "$PROXY_USER" "$PROXY_PASS"
chown proxy:proxy /etc/squid/passwd
chmod 0640 /etc/squid/passwd

cat > /etc/squid/squid.conf <<EOF
# PERDI PROXY - generated configuration
http_port 3128

auth_param basic program /usr/lib/squid/basic_ncsa_auth /etc/squid/passwd
auth_param basic realm PERDI-PROXY
auth_param basic credentialsttl 2 hours
acl authenticated proxy_auth REQUIRED
acl permitted_client src ${CLIENT_IP}/32

# Permit authenticated requests only from the selected client IP.
http_access allow permitted_client authenticated
http_access deny all

cache deny all
access_log stdio:/var/log/squid/access.log
visible_hostname perdi-proxy
EOF

squid -k parse
systemctl enable squid
systemctl restart squid

# Preserve the current SSH port before enabling/changing UFW.
SSH_PORT="${SSH_CONNECTION##* }"
if [[ "$SSH_PORT" =~ ^[0-9]+$ ]]; then
  ufw allow "${SSH_PORT}/tcp"
else
  ufw allow OpenSSH
fi
ufw allow from "${CLIENT_IP}" to any port 3128 proto tcp
ufw --force enable

SERVER_IP="$(curl -4 -fsS --max-time 8 https://api.ipify.org 2>/dev/null || true)"
echo
echo "=== PERDI PROXY SIAP ==="
echo "Jenis       : HTTP proxy (mendukung HTTPS melalui CONNECT)"
echo "Server IP   : ${SERVER_IP:-Periksa IP publik VPS di panel penyedia}"
echo "Port        : 3128"
echo "Username    : ${PROXY_USER}"
echo "Password    : (gunakan password yang tadi dibuat)"
echo "Client IP   : ${CLIENT_IP}/32"
echo
echo "Di aplikasi isi:"
echo "  Proxy type : HTTP"
echo "  Host       : IP publik VPS"
echo "  Port       : 3128"
echo "  Username   : ${PROXY_USER}"
echo "  Password   : password yang tadi dibuat"
echo
echo "Tes dari perangkat yang IP-nya diizinkan:"
echo "  curl -x http://${SERVER_IP:-IP_VPS}:3128 -U '${PROXY_USER}:PASSWORD_ANDA' https://example.com/"
echo
echo "Jangan membagikan password proxy. Jika IP perangkat berubah, perbarui aturan UFW"
echo "dan ACL permitted_client di /etc/squid/squid.conf, lalu restart Squid."
