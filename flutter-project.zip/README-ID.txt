PERDI PROXY SERVER - Ubuntu

Paket ini memasang proxy HTTP Squid yang memerlukan username/password.
Squid mendukung akses HTTPS melalui metode CONNECT. Ini bukan VPN dan tidak
mengalihkan seluruh trafik HP secara otomatis.

Persyaratan:
- VPS Ubuntu Server 22.04 atau 24.04
- Akses SSH dengan akun sudo/root
- IP publik VPS
- IP publik perangkat klien yang akan memakai proxy

Cara memasang:
1. Upload install-perdi-proxy.sh ke VPS.
2. Jalankan:
   chmod +x install-perdi-proxy.sh
   sudo bash install-perdi-proxy.sh
3. Masukkan IP publik perangkat klien, username, dan password kuat minimal 16 karakter.
4. Catat IP VPS, port 3128, username, dan password yang ditampilkan.

Pengaturan aplikasi:
- Type: HTTP
- Host: IP publik VPS
- Port: 3128
- Username/password: yang dibuat saat instalasi

Keamanan:
- Firewall hanya mengizinkan IP klien yang dimasukkan saat instalasi.
- Jangan menghapus autentikasi atau membuka port proxy untuk semua orang.
- Jika IP internet perangkat berubah, ubah allowlist firewall dan ACL Squid.
- Gunakan hanya untuk trafik dan akun yang memang berhak Anda akses.
- Simpan password dengan aman.

Perintah pemeriksaan:
  sudo systemctl status squid
  sudo squid -k parse
  sudo journalctl -u squid --no-pager -n 50

Paket ini tidak menyediakan VPS, IP publik, atau layanan proxy yang sudah online.
