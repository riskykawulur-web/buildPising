# FORM / 03 — Photo to 3D Studio

A dark industrial photo-to-3D web app. It accepts PNG/JPG/WebP images, sends them to Meshy Image-to-3D through a server-side API route, polls generation status, previews the GLB in an interactive 3D viewer, and exposes available GLB/OBJ/STL downloads.

## Requirements

- Node.js 18+ (Node 20+ recommended)
- A Meshy API key and sufficient API credits. API usage may incur charges.

## Run locally

1. Extract this project.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env` and add your Meshy API key:
   ```env
   MESHY_API_KEY=your_real_key_here
   PORT=3000
   ```
5. Start:
   ```bash
   npm start
   ```
6. Open `http://localhost:3000`.

## Important

- Never put the Meshy API key in browser JavaScript or commit `.env` to a public repository.
- The API key is read only by `server.js`.
- Meshy accepts a base64 data URI for the source image; the app limits uploads to 20 MB.
- Generation runs asynchronously. The app checks task status every five seconds.
- Download links are supplied by Meshy and may expire according to its asset-retention policy.
- For public deployment, use HTTPS, add authentication/rate limits, configure request limits and abuse protection, and review the provider's current pricing/terms.
- The model viewer is loaded from Google's model-viewer CDN and Google Fonts are used for typography.

## API references

- [Meshy Image to 3D API](https://docs.meshy.ai/en/api/image-to-3d)
- [Meshy Quickstart](https://docs.meshy.ai/en/api/quick-start)
