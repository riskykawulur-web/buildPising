import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const API = 'https://api.meshy.ai/openapi/v1';

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://ajax.googleapis.com"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "blob:", "https:"],
      connectSrc: ["'self'", "https://api.meshy.ai", "https://assets.meshy.ai"],
      modelSrc: ["'self'", "blob:", "https:"],
      objectSrc: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: '22mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function apiHeaders() {
  if (!process.env.MESHY_API_KEY) {
    const err = new Error('API key belum dipasang. Isi MESHY_API_KEY di file .env.');
    err.status = 503;
    throw err;
  }
  return { Authorization: `Bearer ${process.env.MESHY_API_KEY}`, 'Content-Type': 'application/json' };
}

app.post('/api/generate', async (req, res) => {
  try {
    const { imageData, aiModel = 'meshy-7.1', enablePbr = true } = req.body || {};
    if (typeof imageData !== 'string' || !/^data:image\/(png|jpeg|webp);base64,/.test(imageData)) {
      return res.status(400).json({ error: 'Pilih gambar PNG, JPG, atau WebP yang valid.' });
    }
    const approxBytes = Math.floor((imageData.length - imageData.indexOf(',') - 1) * 3 / 4);
    if (approxBytes > 20 * 1024 * 1024) return res.status(413).json({ error: 'Ukuran gambar maksimal 20 MB.' });

    const response = await fetch(`${API}/image-to-3d`, {
      method: 'POST',
      headers: apiHeaders(),
      body: JSON.stringify({
        image_url: imageData,
        ai_model: aiModel,
        should_texture: true,
        enable_pbr: Boolean(enablePbr),
        target_formats: ['glb', 'obj', 'stl']
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return res.status(response.status).json({ error: data.message || data.error || `Meshy error ${response.status}` });
    res.json({ taskId: data.result });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message || 'Tidak bisa memulai proses.' });
  }
});

app.get('/api/task/:id', async (req, res) => {
  try {
    if (!/^[a-zA-Z0-9-]+$/.test(req.params.id)) return res.status(400).json({ error: 'ID tugas tidak valid.' });
    const response = await fetch(`${API}/image-to-3d/${encodeURIComponent(req.params.id)}`, {
      headers: { Authorization: `Bearer ${process.env.MESHY_API_KEY}` }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return res.status(response.status).json({ error: data.message || `Meshy error ${response.status}` });
    res.json({
      status: data.status,
      progress: data.progress ?? 0,
      modelUrls: data.model_urls || {},
      thumbnailUrl: data.thumbnail_url || '',
      taskError: data.task_error || null
    });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Gagal memeriksa status.' });
  }
});

app.listen(PORT, () => console.log(`FORM / 03 running at http://localhost:${PORT}`));
